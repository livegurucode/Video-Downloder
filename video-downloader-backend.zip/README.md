# Video Downloader Backend

This is a simple Express.js backend that uses `yt-dlp` to fetch video formats.

## How to Run

```bash
npm install
node index.js
```

## Endpoint

GET `/api/download?url=VIDEO_URL`